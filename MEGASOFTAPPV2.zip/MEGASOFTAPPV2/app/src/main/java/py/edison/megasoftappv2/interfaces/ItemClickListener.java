package py.edison.megasoftappv2.interfaces;

public interface ItemClickListener {
    void onItemClick(int position);
    void onItemLongClick(int position);
}