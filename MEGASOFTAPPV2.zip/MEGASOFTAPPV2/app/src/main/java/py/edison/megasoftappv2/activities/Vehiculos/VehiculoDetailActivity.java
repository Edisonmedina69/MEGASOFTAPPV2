package py.edison.megasoftappv2.activities.Vehiculos;

public class VehiculoDetailActivity {
}
