package py.edison.megasoftappv2.entidades;

public class Conductor {

    private String id;
    private String nombre;
    private String telefono;
    private String identidadDriver;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public String getIdentidadDriver() {
        return identidadDriver;
    }

    public void setIdentidadDriver(String identidadDriver) {
        this.identidadDriver = identidadDriver;
    }
}
