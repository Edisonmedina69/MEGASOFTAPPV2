package py.edison.megasoftappv2;

import android.app.Activity;

public class MainActivity extends Activity {
}
