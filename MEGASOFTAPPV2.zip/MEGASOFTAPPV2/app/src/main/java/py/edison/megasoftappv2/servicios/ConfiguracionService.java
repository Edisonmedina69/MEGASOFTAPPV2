package py.edison.megasoftappv2.servicios;

public class ConfiguracionService {
}
