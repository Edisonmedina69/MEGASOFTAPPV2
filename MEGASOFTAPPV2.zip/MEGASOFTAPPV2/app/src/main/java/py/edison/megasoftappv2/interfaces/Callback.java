package py.edison.megasoftappv2.interfaces;

public interface Callback {
}
