package py.edison.megasoftappv2.adapters;

public class CoductorAdapter {
}
