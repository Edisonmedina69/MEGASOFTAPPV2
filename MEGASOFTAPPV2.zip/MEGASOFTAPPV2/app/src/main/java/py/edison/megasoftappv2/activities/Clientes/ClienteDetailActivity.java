package py.edison.megasoftappv2.activities.Clientes;

public class ClienteDetailActivity {
}
